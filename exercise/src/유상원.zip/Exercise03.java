package exercise;

public class Exercise03 {

	public static void main(String[] args) {
		int pencils =534;
		int students =30;
		
		int pencilsPerStudent=(   534/30    );
		System.out.println(pencilsPerStudent);
		
		int pencilsLeft=(   534%30    );
		System.out.println(pencilsLeft);
		// TODO Auto-generated method stub

	}

}
