package exercise;

public class Exercise01 {

	public static void main(String[] args) {
		
		int x =10;
		int y =20;
		int z =(x++)+(y--);
		System.out.println(z);
		// TODO Auto-generated method stub

	}

}
