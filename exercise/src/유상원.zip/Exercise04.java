package exercise;

public class Exercise04 {

	public static void main(String[] args) {
		int value =36;
		System.out.println(356-(356%100));
		// TODO Auto-generated method stub

	}

}
