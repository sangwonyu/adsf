package exercise;

public class Exercise05 {

	public static void main(String[] args) {
		int lengthTop = 5;
		int lengthBottom =10;
		int height=7;
		double area = (((5+10)*7)*0.5);
		System.out.println(area);
			
		// TODO Auto-generated method stub

	}

}
