package exercise;

public class Dog implements Ex03_Soundable{
	public String sound() {
		String dog="멍멍";
		return dog;
	}
	

}
