package exercise;

public interface Ex03_Soundable {
	//추상메소드
	String sound();

}
