package exercise;

public class Cat implements Ex03_Soundable{
	
	public String sound() {
		String cat="야옹";
		return cat;
	}

}
