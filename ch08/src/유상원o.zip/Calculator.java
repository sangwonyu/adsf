package Openchallenge0322;

public interface Calculator {
	//추상메소드
	public void add(int a, int b);
	public void substract(int a, int b);
	public void multiply(int a, int b);
}
