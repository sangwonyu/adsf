package Openchallenge0322;

public interface MyMulti {
	//추상메소드
	public int max(int[] args);
	public int min(int[] args);
	public int sum(int[] args);
	public double avg(int[] args);
}
