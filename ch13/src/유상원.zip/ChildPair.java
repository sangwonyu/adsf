package exercise;

public class ChildPair<T, V> extends Pair<T, V> {

	public ChildPair(T t1, V v1) {
		super(t1, v1);
		// TODO Auto-generated constructor stub
	}
}
